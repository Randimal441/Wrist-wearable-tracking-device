import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { createDeviceToken, getUserFromRequest, hashDeviceToken } from '@/lib/api-auth';

export async function GET(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ success: false, message: 'Unauthorized.' }, { status: 401 });
  try {
    const result = await pool.query(
      `SELECT id, device_name, is_active, created_at, last_seen_at
         FROM public.devices WHERE user_id = $1 ORDER BY created_at DESC`,
      [user.userId]
    );
    return NextResponse.json({ success: true, data: result.rows });
  } catch (error) {
    console.error('List devices error:', error);
    return NextResponse.json({ success: false, message: 'Could not load devices.' }, { status: 500 });
  }
}

// Creates a device owned by the authenticated user. The raw token is returned once only.
export async function POST(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ success: false, message: 'Unauthorized.' }, { status: 401 });
  try {
    const body = await req.json();
    const deviceName = typeof body.deviceName === 'string' ? body.deviceName.trim() : '';
    if (!deviceName || deviceName.length > 100) {
      return NextResponse.json({ success: false, message: 'deviceName is required (maximum 100 characters).' }, { status: 400 });
    }
    const token = createDeviceToken();
    const result = await pool.query(
      `INSERT INTO public.devices (user_id, device_name, device_secret_hash)
       VALUES ($1, $2, $3)
       RETURNING id, device_name, is_active, created_at`,
      [user.userId, deviceName, hashDeviceToken(token)]
    );
    return NextResponse.json({
      success: true,
      message: 'Device registered. Copy the token now; it will not be shown again.',
      data: { ...result.rows[0], deviceToken: token },
    }, { status: 201 });
  } catch (error) {
    if ((error as { code?: string }).code === '23505') {
      return NextResponse.json({ success: false, message: 'A device with this name already exists for your account.' }, { status: 409 });
    }
    console.error('Register device error:', error);
    return NextResponse.json({ success: false, message: 'Could not register device.' }, { status: 500 });
  }
}
